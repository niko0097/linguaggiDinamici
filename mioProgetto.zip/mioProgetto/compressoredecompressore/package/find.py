#!/usr/bin/python3
# -*- coding: utf-8 -*-

import os
import sys
from compressoredecompressore.package.print_all      import *
from compressoredecompressore.package.compressore    import *
from compressoredecompressore.package.decompressore  import *
from compressoredecompressore.package.open_pdf       import *
from compressoredecompressore.package.open_txt       import *
from compressoredecompressore.package.open_rtf       import *

### FUNZIONE FIND CHE CERCA FILE E DIRECTORY DA COMPRIMERE/DECOMPRIMERE ###
def find(percorso, r, v, type):

    files = []
    direc = []

    for i in percorso:

        if os.path.isfile(i):
            files.append(i)

        if os.path.isdir(i) and r:
            direc.append(i)

        if os.path.isdir(i) and r == False:
            red("Path e' una directory ma la ricorsione e' disattivata, fermo tutto")
            sys.exit(0)

    if r is False and len(files) == 0:
        red("Nessun file trovato, esco")
        sys.exit(0)

    if r is True and len(direc) == 0:
        red("Nessuna directory trovata, esco")
        sys.exit(0)

    for i in direc:
        find_in_dir(i, v, files)

    ### IN BASE A CHI CHIAMA LA FUNZIONE FIND ANDRO' A COMPRIMERE/DECOMPRIMERE I FILES ###
    if type == 1:
        type1(files, v)
    if type == 2:
        type2(files,v)

    return

### SELEZIONO I FILES DA DECOMPRIMERE ###
def type2(files,v):
    for i in files:
        if ".Z" in i:
            with open (i, 'rb') as fp:
                itemlist = pickle.load(fp)
            decompressor_algorithm(itemlist, v, i)

            copymode(i, i.replace(".Z", ""))

        else:
            red("File non idoneo: {}".format(i))

### SELEZIONO I FILES DA COMPRIMERE ###
def type1(files,v):
    ### UNA VOLTA TROVATI I FILE DA COMPRIMERE LI MANDO ALLE FUNZIONI NECESSARIE ###
    for i in files:
        #STRUTTURA USATA PER IL CALCOLO DEL TEMPO IMPIEGATO
        millis = int(round(time.time() * 1000))

        ###TXT###
        if ".txt" in i and ".Z" not in i:
            if len(open(i, "r").read()) != 0:
                open_txt(i, v)
            else:
                red("File vuoto: {}".format(i))

        ###RTF###
        elif ".rtf" in i and ".Z" not in i:
            if len(open(i, "r").read()) != 0:
                open_rtf(i, v)
            else:
                red("File vuoto: {}".format(i))

        ###PDF###
        elif ".pdf" in i and ".Z" not in i:
            open_pdf(i,v)

        ###.Z###
        elif ".Z" in i:
            red("File gia compressoe")

        else:
            red("File non idoneo: {}".format(i))

        millis1 = int(round(time.time() * 1000))

    return

### TROVA IN MANIERA RICORSIVA I FILE E LE SOTTODIRECTORY DI UNA CARTELLA PASSATA DA INPUT ###
def find_in_dir(dir, v, files):
    things = []
    things = os.listdir(dir)
    for i in things:
        if os.path.isdir(os.path.join(dir, i)):
            find_in_dir(os.path.join(dir, i), v, files)

        if os.path.isfile(os.path.join(dir, i)):
            files.append(os.path.join(dir, i))
