#!/usr/bin/python3
# -*- coding: utf-8 -*-

from compressoredecompressore.package.print_all      import *
from compressoredecompressore.package.compressore    import *

def open_pdf(file,v):
    try:
        pdf = open(file, "r").read()
        compressor_algorithm(pdf, v, file)
    except:
        red("Non posso aprire il file")

    return
