#!/usr/bin/python3
# -*- coding: utf-8 -*-

import pickle
import time
import os
import subprocess
from shutil 										import copymode
from compressoredecompressore.package.print_all  	import *
from compressoredecompressore.package.find       	import *

def compressor_algorithm(uncompressed,verbose, file):
	"""Compress a string to a list of output symbols."""

	# Build the dictionary.
	dict_size = 256
	dictionary = {chr(i): i for i in range(dict_size)}

	w = ""
	result = []
	for c in uncompressed:
		wc = w + c
		if wc in dictionary:
			w = wc
		else:
			result.append(dictionary[w])
			# Add wc to the dictionary.
			dictionary[wc] = dict_size
			dict_size += 1
			w = c

	# Output the code for w.
	if w:
		result.append(dictionary[w])

	f= open(file + ".Z","w+")

	'''
	Scrivo l'output nella stessa directory e con uguale nome + ".Z"
	'''

	with open(file + ".Z", 'wb+') as fp:
		pickle.dump(result, fp)

	copymode(file, file + ".Z")

	if verbose:
		green("Rapporto compressione: {}".format((os.path.getsize(file) - os.path.getsize(file + ".Z")) * 100 / os.path.getsize(file)))

	if os.path.getsize(file) < os.path.getsize(file + ".Z"):
		red("File compresso ma la dimensione del file compresso e' maggiore, elimino il file compresso")
		subprocess.run("rm " + file + ".Z", shell=True)

	green("Compressione terminata : {}".format(file + ".Z"))
	subprocess.run("rm " + file, shell=True)
	return
