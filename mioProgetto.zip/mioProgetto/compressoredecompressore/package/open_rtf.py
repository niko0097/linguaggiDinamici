#!/usr/bin/python3
# -*- coding: utf-8 -*-

from compressoredecompressore.package.print_all      import *
from compressoredecompressore.package.compressore    import *

def open_rtf(file, v):
    try:
        rtf = open(file, "r").read()
        compressor_algorithm(rtf, v, file)
    except:
        red("Non posso aprire il file")

    return
