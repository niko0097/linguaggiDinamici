__all__ =["compressore","decompressore","find","print_all"]
