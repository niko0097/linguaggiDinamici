#!/usr/bin/python3
# -*- coding: utf-8 -*-

import pickle
import time
from io 				import StringIO
from compressoredecompressore.package.print_all  import *
from compressoredecompressore.package.find       import *

def decompressor_algorithm(txt, verbose, p):
	"""Decompress a list of output ks to a string."""

	# Build the dictionary.
	dict_size = 256
	dictionary = {i: chr(i) for i in range(dict_size)}

	result = StringIO()
	w = chr(txt.pop(0))
	result.write(w)
	for k in txt:
		if k in dictionary:
			entry = dictionary[k]
		elif k == dict_size:
			entry = w + w[0]
		else:
			raise ValueError('Bad compressed k: %s' % k)
		result.write(entry)

		# Add w+entry[0] to the dictionary.
		dictionary[dict_size] = w + entry[0]
		dict_size += 1
		w = entry

	nomefile = p.replace(".Z", "")
	with open(nomefile, 'w+') as fp:
		fp.write(result.getvalue())

	green("File {} decompresso".format(nomefile))

	return result.getvalue()
