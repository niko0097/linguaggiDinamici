#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import platform
import os

if "Darwin" in platform.system():
    print("Mac OS")

    print("Fetching pip")
    bashCommand = "sudo easy_install pip && sudo pip install --upgrade pip"
    os.system(bashCommand)

    print("pip3 install colorama")
    bashCommand = "sudo pip install colorama"
    os.system(bashCommand)

    print("pip3 install argparse")
    bashCommand = "sudo pip install argparse"
    os.system(bashCommand)

elif "Linux" in platform.system():
    print("Linux")

    print("Fetching python3")
    bashCommand = "sudo apt install python3"
    os.system(bashCommand)

    print("Fetching pip")
    bashCommand = "sudo apt-get install python3-pip"
    os.system(bashCommand)

    print("pip3 install colorama")
    bashCommand = "sudo pip install colorama"
    os.system(bashCommand)

    print("pip3 install argparse")
    bashCommand = "sudo pip install argparse"
    os.system(bashCommand)
else:
    red("Unknown")
    sys.exit(-1)

print("Dipendenze per CompressorLZ Installate correttamente")

try:
    from distutils.core import setup
except ModuleNotFoundError:
    print("ATTENZIONE! \ndistutils non è installato.\n")
    print("Fetching python3-distutils")
    bashCommand = "sudo apt install python3-distutils"
    os.system(bashCommand)




setup (name='Compressore - Decompressore',
      version='1.0',
      description='Compressore - Decompressore Lempel-Ziv-Welch',
      author='Nicola Baccarani',
      author_email='225965@studenti.unimore.it',
      url='',
      license='None',
      packages = ['compressoredecompressore/package'],
      scripts=['compressoredecompressore/compressore','compressoredecompressore/decompressore'],
     )
