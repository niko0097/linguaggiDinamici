README.md


/*****************************************************************************************/
#
# Progetto d'esame Linguaggi Dinamici: Compressore/Decompressore algoritmo Lempel-Ziv-Welch.
#
# Autore: Nicola Baccarani
# Matricola: 108935 UNIMORE CdL Informatica.
# 
/*****************************************************************************************/

Istruzioni:
	- Per installare il comando lanciare il comando:
		"python3 setup.py install"

		lo script "setup.py" prenderà in carico la richiesta di installazione e installerà le dipendenze
		necessarie per il corretto funzionamento del programma.
		Dopo l'installazione sarà possibile lanciare il programma da terminale lanciato i comandi "compressore" o "decompressore"

	- Per comprimere un file:
		"compressore PATH"

		Il programma prenderà in carico la richiesta di compressione e creerà un file con i medesimi permessi del file originale con estensione ".Z".
		N.B. Alla fine della compressione il programma eseguirà un controllo sulle dimensioni dei file; qualora il file compresso
		dovesse essere più pesante del file NON compresso(a causa dell'overhead creato dalla compressione) il programma eliminerà il file compresso pocanzi.
		N.B.2. Al fine di poter ottenere una compressione funzionante il programma è stato progettato in modo da poter funzionare SOLAMENTE su file
		codificati con caratteri UTF-8.

	- Per decomprimere un file:
		"decompressore PATH"

		Il programma prenderà in carico la richiesta di decompressione su file con estensione ".Z" creeando un file con estensione e permessi uguali all'originale.

Olteriori Informazioni:
	
	- I comandi descritti in precedenza hanno 2 modalità:

		- Ricorsiva:
			Dovrà essere lanciata non su di un file, ma su di una intera directory, il programma lancierà un suo modulo "find" che cercherà in modo ricorsivo tutti i file idonei alla compressione(e decompressione) nella cartella e nelle sue rispettive sotto-cartelle.

		- Singola:
			Il programma lancerà la "find" sul file specificato cercando di capire se il file specificato è idoneo alla compressione, verificato questo il programma procederà con la compressione.

	- Se si include nel comando il flag "-v" si lancerà il programma in modalità verbose.

Difetti:
	- A causa di un mancato supporto per il modulo Python "Textract" che serve per aprire ed estrarre il testo dai file ".pdf" non può essere installato; perciò i file ".pdf" non saranno compressi.